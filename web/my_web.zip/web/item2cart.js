    // Retrieve the cart from localStorage
    var cart = JSON.parse(localStorage.getItem('cart'));

    // Get the cart list element
    var cartList = document.getElementById('cart-list');

    // Function to display the items in the cart
    function displayCartItems() {
      // Clear the existing list
      cartList.innerHTML = '';

      // Calculate the total price
      var totalPrice = 0;

      // Iterate over each item in the cart
      cart.forEach(function(item) {
        // Check if the item already exists in the cart
        var existingItem = cartList.querySelector(`li[data-name="${item.name}"]`);

        if (existingItem) {
          // If the item exists, increment its quantity
          var quantityElement = existingItem.querySelector('.quantity');
          var quantity = parseInt(quantityElement.textContent);
          quantityElement.textContent = quantity + 1;
          return; // Exit the function to prevent further execution
        } 
        else {
          // If the item doesn't exist, create a new list item
          var listItem = document.createElement('li');
          listItem.dataset.name = item.name;

          // Create item details
          var itemName = document.createElement('span');
          itemName.textContent = item.name;

          var itemPrice = document.createElement('span');
          itemPrice.textContent = item.price + ' تومان';

          var quantityWrapper = document.createElement('div');
          quantityWrapper.className = 'quantity-wrapper';

          const decreaseButton = document.createElement('button');
          decreaseButton.textContent = '-';
          decreaseButton.addEventListener('click', function() {
            // Decrease the quantity of the item
            var quantityElement = this.nextElementSibling;
            var quantity = parseInt(quantityElement.textContent);
            if (quantity > 1) {
              quantityElement.textContent = quantity - 1;
            }
          });

          var quantityElement = document.createElement('span');
          quantityElement.className = 'quantity';
          quantityElement.textContent = '1';

          const increaseButton = document.createElement('button');
          increaseButton.textContent = '+';
          increaseButton.addEventListener('click', function() {
            // Increase the quantity of the item
            var quantityElement = this.previousElementSibling;
            var quantity = parseInt(quantityElement.textContent);
            quantityElement.textContent = quantity + 1;
          });

          // Create remove button
          var removeButton = document.createElement('button');
          removeButton.textContent = 'حذف';
          removeButton.addEventListener('click', function() {
            // Remove the item from the cart
            var listItem = this.closest('li');
            var itemName = listItem.dataset.name;

            listItem.remove();

            cart = cart.filter(function(item) {
              return item.name !== itemName;
            });

            localStorage.setItem('cart', JSON.stringify(cart));

            // Update the total price
            displayTotalPrice();
            });
          // Append elements to the list item
          quantityWrapper.appendChild(decreaseButton);
          quantityWrapper.appendChild(quantityElement);
          quantityWrapper.appendChild(increaseButton);

          listItem.appendChild(itemName);
          listItem.appendChild(itemPrice);
          listItem.appendChild(quantityWrapper);
          listItem.appendChild(removeButton);

          // Append the list item to the cart list
          cartList.appendChild(listItem);
        }

        // Calculate the total price
        totalPrice += parseInt(item.price);
      });

      // Update the total price element
      var totalPriceElement = document.getElementById('total-price-value');
      totalPriceElement.textContent = totalPrice;
    }

    // Check if the cart exists in the localStorage
    if (cart === null) {
      // If the cart doesn't exist, create an empty array
      cart = [];
    }

    // Display the cart items initially
    displayCartItems();

    //purchase button
    var purchaseButton = document.getElementById('purchase-button');
    purchaseButton.addEventListener('click', function() {
      
      alert('!با تشکر از خرید شما');

      // Reset the cart and update localStorage
      cart = [];
      localStorage.setItem('cart', JSON.stringify(cart));

      // Re-display the cart items
      displayCartItems();
    });